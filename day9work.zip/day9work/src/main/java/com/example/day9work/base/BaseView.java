package com.example.day9work.base;

public interface BaseView {
    void onToast(String str);
}
