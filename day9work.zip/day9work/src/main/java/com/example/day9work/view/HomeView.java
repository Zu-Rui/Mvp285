package com.example.day9work.view;

import com.example.day9work.base.BaseView;
import com.example.day9work.bean.HomeBean;

public interface HomeView extends BaseView {
    void setData(HomeBean homeBean);
}
